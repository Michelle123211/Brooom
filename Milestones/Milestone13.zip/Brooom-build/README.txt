This directory contains a build for Windows PC (64-bit).
The game can be started by running the Brooom.exe file.

There are also two helper files:
- GoToSaveLocation - A shortcut which will take you to a folder where the game's data is stored (e.g. save files).
- DeleteSaveFiles - A batch file which deletes all the game's data stored in the folder accessible by GoToSaveLocation shortcut.
		  - It replaces an uninstaller, because the game is not actually installed on the system.
